import axios from "axios";
import {
  getAccessToken,
  getRefreshToken,
  saveAccessToken,
  clearTokens,
} from "./utils/secureStorage";
const api = axios.create();

api.defaults.withCredentials = true;

api.interceptors.request.use(async (config) => {
  const accessToken = await getAccessToken();
  console.log(await getRefreshToken())
  console.log(accessToken)
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }

  return config;
});

api.interceptors.response.use(
  (response) => response,

  async (error) => {
    const originalRequest = error.config;

    if (
      error.response?.status === 401 &&
      !originalRequest._retry
    ) {
      originalRequest._retry = true;
      try {
        const refreshToken = await getRefreshToken();

        if (!refreshToken) {
          throw new Error("No refresh token found.");
        }

        // Get backend host from the original request
        const backendHost = new URL(originalRequest.baseURL).origin;

        const response = await axios.post(
          `${backendHost}/refreshtoken`,
          {
            refreshToken,
          }
        );

        const newAccessToken = response.data.accessToken;

        await saveAccessToken(newAccessToken);

        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;

        return axios(originalRequest);

      } catch (refreshError) {
        await clearTokens();
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export default api