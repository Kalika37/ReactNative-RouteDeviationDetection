import React from "react";
import { useAuth } from "../authenticate/AuthProvider";
import { View, ActivityIndicator } from "react-native";
import { useNavigation } from "@react-navigation/native";
import LoadingScreen from './LoadingScreen';

export default function AdminGuard({ children }) {
  const { authenticated, loading,error } = useAuth();
  const navigation = useNavigation();
  if (loading) {
    return <LoadingScreen error={error}/>
  }
  if (!authenticated) {
    // redirect normal users
    navigation.replace("Auth", {screen:"Login"}); // or "Home"
    return null;
  }

  return children;
}