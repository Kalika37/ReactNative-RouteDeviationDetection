import React from "react";
import { useAuth } from "../authenticate/AuthProvider";
import { useNavigation } from "@react-navigation/native";
import LoadingScreen from './LoadingScreen';

export default function AdminGuard({ children }) {
  const { adminAccess, loading, error } = useAuth();
  const navigation = useNavigation();
  console.log("ADmin")
  if (loading) {
    return <LoadingScreen error={error}/>
  }

  if (!adminAccess) {
    // redirect normal users
    navigation.replace("App"); // or "Home"
    return null;
  }

  return children;
}